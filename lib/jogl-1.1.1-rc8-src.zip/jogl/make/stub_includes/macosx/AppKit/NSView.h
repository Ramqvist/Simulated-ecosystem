typedef struct _NSView NSView;
