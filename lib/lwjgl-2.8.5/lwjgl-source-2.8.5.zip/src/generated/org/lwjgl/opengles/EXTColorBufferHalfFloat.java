/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTColorBufferHalfFloat {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorage and
	 *  RenderbufferStorageMultisampleAPPLE:
	 */
	public static final int GL_RGBA16F_EXT = 0x881A,
		GL_RGB16F_EXT = 0x881B,
		GL_RG16F_EXT = 0x822F,
		GL_R16F_EXT = 0x822D;

	/**
	 * Accepted by the &lt;pname&gt; parameter of GetFramebufferAttachmentParameteriv: 
	 */
	public static final int GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE_EXT = 0x8211;

	/**
	 * Returned in &lt;params&gt; by GetFramebufferAttachmentParameteriv: 
	 */
	public static final int GL_UNSIGNED_NORMALIZED_EXT = 0x8C17;

	private EXTColorBufferHalfFloat() {}
}
