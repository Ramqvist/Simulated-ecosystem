/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESDepth32 {

	/**
	 * Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorageOES: 
	 */
	public static final int GL_DEPTH_COMPONENT32_OES = 0x81A7;

	private OESDepth32() {}
}
