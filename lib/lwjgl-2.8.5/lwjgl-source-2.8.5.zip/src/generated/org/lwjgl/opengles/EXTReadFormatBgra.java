/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTReadFormatBgra {

	/**
	 * Accepted by the &lt;format&gt; parameter of ReadPixels: 
	 */
	public static final int GL_BGRA_EXT = 0x80E1;

	/**
	 * Accepted by the &lt;type&gt; parameter of ReadPixels: 
	 */
	public static final int GL_UNSIGNED_SHORT_4_4_4_4_REV_EXT = 0x8365,
		GL_UNSIGNED_SHORT_1_5_5_5_REV_EXT = 0x8366;

	private EXTReadFormatBgra() {}
}
