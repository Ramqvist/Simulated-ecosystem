/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBStencilTexturing {

	/**
	 * Accepted by the &lt;pname&gt; parameter of TexParameter* and GetTexParameter*: 
	 */
	public static final int GL_DEPTH_STENCIL_TEXTURE_MODE = 0x90EA;

	private ARBStencilTexturing() {}
}
