/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTBgra {

	public static final int GL_BGR_EXT = 0x80E0,
		GL_BGRA_EXT = 0x80E1;

	private EXTBgra() {}
}
