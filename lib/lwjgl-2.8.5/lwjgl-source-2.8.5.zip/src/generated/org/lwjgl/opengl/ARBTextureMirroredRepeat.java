/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBTextureMirroredRepeat {

	public static final int GL_MIRRORED_REPEAT_ARB = 0x8370;

	private ARBTextureMirroredRepeat() {}
}
