java \
 -Djava.library.path=../../com.amd.aparapi.jni/dist \
 -classpath ../../com.amd.aparapi/dist/aparapi.jar:info.jar \
 com.amd.aparapi.sample.info.Main
